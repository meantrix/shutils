version () {
    local v="0.0.1"
    echo "shutils ($v) unstable; urgency=medium"
}